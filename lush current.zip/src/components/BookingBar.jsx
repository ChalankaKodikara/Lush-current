import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { CalendarDays, ChevronDown, Users } from "lucide-react";
import { DayPicker } from "react-day-picker";
import { format } from "date-fns";

import "react-day-picker/dist/style.css";

export default function BookingBar() {
  const nav = useNavigate();

  const [form, setForm] = useState({
    checkIn: null,
    checkOut: null,
    guests: 2,
  });

  const [openPicker, setOpenPicker] = useState(null);

  const go = () => {
    const checkIn = form.checkIn ? format(form.checkIn, "yyyy-MM-dd") : "";

    const checkOut = form.checkOut ? format(form.checkOut, "yyyy-MM-dd") : "";

    nav(
      `/booking?checkIn=${checkIn}&checkOut=${checkOut}&guests=${form.guests}`,
    );
  };

  const today = new Date();

  return (
    <div className="booking-bar-modern">
      {/* CHECK IN */}
      <div className="booking-field">
        <button
          type="button"
          className="booking-field-button"
          onClick={() =>
            setOpenPicker(openPicker === "checkIn" ? null : "checkIn")
          }
        >
          <div className="booking-field-icon">
            <CalendarDays size={18} />
          </div>

          <div className="booking-field-content">
            <span className="booking-field-label">Check in</span>

            <strong>
              {form.checkIn
                ? format(form.checkIn, "dd MMM yyyy")
                : "Select date"}
            </strong>
          </div>

          <ChevronDown size={16} />
        </button>

        {openPicker === "checkIn" && (
          <div className="booking-calendar-popover">
            <DayPicker
              mode="single"
              selected={form.checkIn}
              onSelect={(date) => {
                if (!date) return;

                setForm((prev) => ({
                  ...prev,
                  checkIn: date,
                  checkOut:
                    prev.checkOut && prev.checkOut <= date
                      ? null
                      : prev.checkOut,
                }));

                setOpenPicker("checkOut");
              }}
              disabled={{ before: today }}
              className="villa-calendar"
            />
          </div>
        )}
      </div>

      {/* CHECK OUT */}
      <div className="booking-field">
        <button
          type="button"
          className="booking-field-button"
          onClick={() =>
            setOpenPicker(openPicker === "checkOut" ? null : "checkOut")
          }
        >
          <div className="booking-field-icon">
            <CalendarDays size={18} />
          </div>

          <div className="booking-field-content">
            <span className="booking-field-label">Check out</span>

            <strong>
              {form.checkOut
                ? format(form.checkOut, "dd MMM yyyy")
                : "Select date"}
            </strong>
          </div>

          <ChevronDown size={16} />
        </button>

        {openPicker === "checkOut" && (
          <div className="booking-calendar-popover">
            <DayPicker
              mode="single"
              selected={form.checkOut}
              onSelect={(date) => {
                if (!date) return;

                setForm((prev) => ({
                  ...prev,
                  checkOut: date,
                }));

                setOpenPicker(null);
              }}
              disabled={{
                before: form.checkIn
                  ? new Date(
                      form.checkIn.getFullYear(),
                      form.checkIn.getMonth(),
                      form.checkIn.getDate() + 1,
                    )
                  : today,
              }}
              className="villa-calendar"
            />
          </div>
        )}
      </div>

      {/* GUESTS */}
      <div className="booking-field">
        <div className="booking-field-button">
          <div className="booking-field-icon">
            <Users size={18} />
          </div>

          <div className="booking-field-content">
            <span className="booking-field-label">Guests</span>

            <select
              value={form.guests}
              onChange={(e) =>
                setForm((prev) => ({
                  ...prev,
                  guests: Number(e.target.value),
                }))
              }
              className="booking-guest-select"
            >
              {[1, 2, 3, 4, 5, 6].map((guest) => (
                <option key={guest} value={guest}>
                  {guest} {guest === 1 ? "Guest" : "Guests"}
                </option>
              ))}
            </select>
          </div>

          <ChevronDown size={16} />
        </div>
      </div>

      {/* BUTTON */}
      <button type="button" className="booking-availability-btn" onClick={go}>
        Check availability
      </button>
    </div>
  );
}
